import src.oyoms as om

# 'local' or 'blob'
config = om.AuthConfig(user='test@oyorooms.com', style='local', tenant='OYO')

oc = om.OutlookClient(config)

res = oc.get('/me/messages')

print(res.get('value')[0].get('subject'))

share_url = 'https://oyoenterprise-my.sharepoint.com/:x:/g/personal/stephen_lee_oyorooms_com/EU1EznaA78hRtmXzkfD7bSoBOp1_zZT57B1i3OoNf7ICBA?e=USjSw2'
wc = om.WorkbookClient(config, share_url)

print(wc.get_sheet_list())
