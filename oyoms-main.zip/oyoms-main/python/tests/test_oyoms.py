# Test everything!


import pytest
import src.oyoms as om
from pathlib import Path
import pandas as pd


@pytest.fixture(scope='session')
def user(pytestconfig):
    return pytestconfig.getoption('user')


@pytest.fixture(scope='session')
def auth_config(user):
    return om.AuthConfig(user)


@pytest.fixture(scope='session')
def dc(auth_config):
    return om.DriveClient(auth_config)


@pytest.fixture(scope='session')
def path():
    return str(Path('OYOMS Test') / pd.Timestamp.utcnow().strftime('%Y%m%d_%H_%M_%S'))


@pytest.fixture(scope='session')
def xl_path(path):
    return str(Path(path) / 'test.xlsx')


@pytest.fixture(scope='session')
def df():
    return pd.DataFrame({'a': [1, 2, 3], 'b': ['one', 'two', 'three']})


# Create a test folder
def test_folder_create(dc, path):
    res = dc.get_folder(path)
    assert isinstance(res, tuple) and len(res) == 3


# Upload a CSV
def test_csv_upload(dc, path, df):
    res = dc.df_to_csv(df, str(Path(path) / 'test.csv'), index=False)
    assert isinstance(res, dict)


# Upload an XLSX
def test_xlsx_upload(dc, xl_path, df):
    res = dc.df_to_xlsx(df, xl_path, index=False, sheet_name='My Data')
    assert(isinstance(res, dict))


# Get a DriveItem
def test_get_drive_item(dc, xl_path):
    res = dc.get_item(xl_path)
    assert(isinstance(res, dict))


# Set up the WorkbookClient
@pytest.fixture(scope='session')
def wc(auth_config, dc, xl_path):
    return om.WorkbookClient(auth_config, drive_item=dc.get_item(xl_path))


# Test the sheet read
def test_xl_sheet_read(wc):
    assert wc.get_sheet_list() == ['My Data']


# Test sheet creation
def test_xl_sheet_create(wc):
    wc.create_sheet('Test Sheet')
    assert True


# Test Data Read
def test_xl_read(wc, df):
    data = wc.get_range_data('My Data')
    assert data.shape == df.shape


# Test Data Clear
def test_xl_clear(wc):
    wc.clear_range('My Data')
    assert True


# Test Data Write Single
def test_xl_write_value(wc):
    wc.write_value('My Data', 'A1', 1)
    assert True


# Test Data Write Df
def test_xl_write_data(wc, df):
    wc.write_data('Test Sheet', df)
    assert True


# Test Data Append
def test_xl_append_data(wc, df):
    wc.append_data('Test Sheet', df)
    assert True
