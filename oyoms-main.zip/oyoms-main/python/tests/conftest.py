# Test configuration


def pytest_addoption(parser):
    parser.addoption('--user', action='store', default='stephen.lee@oyorooms.com')
