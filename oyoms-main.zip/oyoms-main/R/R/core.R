#' Core Client for Microsoft Graph API
#'
#' @description Constructs a custom HTTP Client to be used for requests against
#'   the Microsoft Graph API for a specific type of resource. This Client will
#'   act on behalf of an Azure User via an application registered through Azure
#'   AD. Each core_client can carry its own base resource path, which can
#'   simplify API calls for classes which inherit from it.
#'
#' @field token Token cached with the client
#' @field resource_path Resource path for this client
#' @field config Instance of auth_config used to create this client
#'
#' @export
core_client <- R6::R6Class("core_client",

public = list(

    token = NULL,
    resource_path = "",
    config = NULL,

    #' @description Create a new Core Client. You provide either a user or an
    #'   auth_config.
    #' @param config An instance of auth_config, or a username string.
    #' @param scopes A character vector containing the desired scopes.
    initialize = function(
        config,
        scopes = c("https://graph.microsoft.com/user.read")) {

        if (!is.character(config) & !is(config, "auth_config")) {
            stop("config must be charatcer or auth_config.")
        }

        if (is.character(config)) {
            config <- auth_config$new(config)
        }
        self$config <- config

        cred <- device_code_credential$new(self$config)
        self$token <- cred$get_token(scopes)

        private$custom_resource_path()
    },

    #' @description GET request
    #' @param path API path to append to the core_client's resource path
    #' @param ... Other options that can get passed to an HTTP request.
    get = function(path, ...) {
        private$request('GET', path, ...)
    },

    #' @description PUT request
    #' @param path API path to append to the core_client's resource path
    #' @param ... Other options that can get passed to an HTTP request.
    put = function(path, ...) {
        private$request('PUT', path, ...)
    },

    #' @description POST request
    #' @param path API path to append to the core_client's resource path
    #' @param ... Other options that can get passed to an HTTP request.
    post = function(path, ...) {
        private$request('POST', path, ...)
    },

    #' @description PATCH request
    #' @param path API path to append to the core_client's resource path
    #' @param ... Other options that can get passed to an HTTP request.
    patch = function(path, ...) {
        private$request('PATCH', path, ...)
    },

    #' @description DELETE request
    #' @param path API path to append to the core_client's resource path
    #' @param ... Other options that can get passed to an HTTP request.
    delete = function(path, ...) {
        private$request('DELETE', path, ...)
    }
),

private = list(

    # Set up a custom root resource path for your instantiation of the Client.
    #   Useful to help make subsequent API calls look cleaner.
    custom_resource_path = function() {},

    # Generic method to perform a request of any type via the client.
    request = function(request_type, request_path, ...) {
        path <- URLencode(paste0(self$resource_path, request_path))
        private$custom_request(request_type, path, ...)
    },

    # Allows override for the request behavior. Default behavior
    #   is a standard single request.
    custom_request = function(request_type, path, ...) {
        AzureGraph::call_graph_endpoint(
            self$token,
            path,
            http_verb = request_type,
            ...)
    }
))
