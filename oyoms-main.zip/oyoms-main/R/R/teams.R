#' Client for interacting with Teams
#'
#' @description
#' Constructs a custom HTTP Client to be used for requests for Teams.
#'
#' This Client will act on behalf of an Azure User via an application
#'   registered through Azure AD.
#'
#' @export
teams_client <- R6::R6Class("teams_client", inherit = core_client,

public = list(

    #' @description Create a new Teams Client. You provide either the user
    #'   or an auth_config.
    #' @param config An instance of auth_config, or the username string.
    initialize = function(config) {

        scopes <- c("https://graph.microsoft.com/channelmessage.send",
                    "https://graph.microsoft.com/chat.readwrite",
                    "https://graph.microsoft.com/user.readbasic.all")
        super$initialize(config, scopes = scopes)
    },

    #' @description Send a message to a Teams Channel or Chat. You must provide
    #'   either a Chat ID or a Channel URL. To find a Chat ID, try using the
    #'   TeamsClient.get_chat_list function. To find a Channel URL, click ...
    #'   next to the Channel name and select "Get link to channel". If the
    #'   Channel only provides the "Get email address" option, then you can
    #'   instead use the OutlookClient to send an email to the channel. Images
    #'   and attachments must be locally stored, and supplied as a list of local
    #'   file path strings. Images will be shown in the body of the message,
    #'   at the end. You can tag users in the message itself by using the
    #'   pattern $TAG(user-email-address).
    #' @param message String containing the message to send to the channel.
    #'   Interpreted as HTML string.
    #' @param chat_id Optional string with the Chat ID number.
    #' @param channel_url Optional string with the Channel URL.
    #' @param images Optional list of local file paths to images to include in
    #'   the message.
    #' @param attachments Optional list of local file paths to attachments to
    #'   include in the message.
    send_message = function(
        message,
        chat_id=NULL,
        channel_url=NULL,
        images=NULL,
        attachments=NULL) {

        if (is.null(chat_id) & is.null(channel_url)) {
            stop("Must provide either chat_id or channel_url!")
        }

        if (!is.null(chat_id) & !is.null(channel_url)) {
            stop("Only provide a chat_id or a channel_url!")
        }

        # Get the URLs
        if (!is.null(chat_id)) {
            url <- paste0("/chats/", chat_id, "/messages")
            channel_id <- ""
        } else {
            channel_id <- gsub(".*channel/(.+)/.*", "\\1", channel_url)
            team_id <- gsub(".*groupId=(.+)&.*", "\\1", channel_url)
            url <- paste0("/teams/",
                          team_id,
                          "/channels/",
                          channel_id,
                          "/messages")
        }

        # Message body by default is just the message
        body <- message

        # Parse and replace user tagging, identified by $TAG(user@oyorooms.com)
        tags <- stringr::str_extract_all(body, "\\$TAG\\(.+?\\)")[[1]]
        mentions <- c()
        if (length(tags) > 0) {
            for (i in seq_along(tags)) {
                user <- substr(tags[i], 6, nchar(tags[i]) - 1)

                if (tolower(user) == "channel" & nchar(channel_id) > 0) {
                    user_name <- "Here"
                    mention_list <- list(
                        conversation = list(
                            displayName = user_name,
                            id = URLdecode(channel_id),
                            conversationIdentityType = "channel"
                        ))
                } else {
                    skip_to_next <- FALSE
                    tryCatch({
                        user_info <- self$get(
                            paste0("/users('",
                                   user,
                                   "')?$select=id,displayName"))
                    }, error = function(e) { skip_to_next <<- TRUE })
                    if (skip_to_next) { next }

                    user_name <- user_info$displayName
                    mention_list <- list(
                        user = list(
                            displayName = user_name,
                            id = user_info$id,
                            userIdentityType = "aadUser"
                        ))
                }

                mentions <- append(
                    mentions,
                    list(list(
                        id = i,
                        mentionText = user_name,
                        mentioned = mention_list
                    ))
                )

                body <- gsub(tags[i],
                             paste0("<at id=\"",
                                    i,
                                    "\">",
                                    user_name,
                                    "</at>"),
                             body,
                             fixed = TRUE)
            }
        }

        # Attach images if possible
        hosted_content <- c()
        if (is.null(images)) images = c()
        for (i in seq_along(images)) {
            image_path <- images[[i]]

            # Images need to be base64 encoded
            image_base64 <- base64enc::base64encode(image_path)

            # Get file dimensions
            ext <- tools::file_ext(image_path)
            if (ext == "png") {
                img_array <- png::readPNG(image_path)
            } else if (ext == "jpg" | ext == "jpeg") {
                img_array <- jpeg::readJPEG(image_path)
            } else {
                stop('Uploaded image must be PNG or JPEG.')
            }
            height <- dim(img_array)[1]
            width <- dim(img_array)[2]

            body <- paste0(
                body,
                "<br><span><img src=\"../hostedContents/",
                i,
                "/$value\" height=\"",
                height,
                "\" width=\"",
                width,
                "\"></span>"
            )
            hosted_content <- append(
                hosted_content,
                list(list(
                    `@microsoft.graph.temporaryId` = as.character(i),
                    contentBytes = image_base64,
                    contentType = "image/png"
                ))
            )
        }

        # Attach attachments if possible
        attach_list <- c()
        if (is.null(attachments)) attachments = c()
        if (length(attachments) > 0) {
            dc <- drive_client$new(self$config)

            # Get the drive location for file uploads for Channels
            params = list(target_path = "OYOMS Uploads/")
            if (!is.null(channel_url)) {
                res <- self$get(paste0("/teams/",
                                       team_id,
                                       "/channels/",
                                       channel_id,
                                       "/filesFolder"))
                drive_root = paste0("/drives/",
                                    res$parentReference$driveId,
                                    "/items/",
                                    res$id)
                params = c(params, list(drive_root = drive_root))
            }

            for (i in seq_along(attachments)) {
                if (class(attachments[[i]])[1] == "workbook_client") {
                    res <- attachments[[i]]$drive_item
                } else {
                    res <- do.call(dc$upload_file,
                                   c(list(file_path = attachments[[i]]),
                                     params))
                }

                # Extract the necessary information, construct the attachment
                attach_id <- gsub(".*\\{(.+)\\}.*", "\\1", res$eTag)
                parent <- res$parentReference
                parent_folder <- dc$get(paste0("/drives/",
                                               parent$driveId,
                                               "/items/",
                                               parent$id
                                               ))

                body <- paste0(
                    body,
                    "<attachment id=\"",
                    attach_id,
                    "\"></attachment>"
                )
                attach_list <- append(
                    attach_list,
                    list(list(
                        id = attach_id,
                        contentType = "reference",
                        contentUrl = paste0(parent_folder$webUrl,
                                            "/",
                                            res$name),
                        name = res$name
                    ))
                )
            }
        }

        # Compile the JSON Body
        json_body <- list(body = list(
            contentType = "html",
            content = paste0("<div>", body, "</div>")
        ))
        if (length(mentions) > 0) {
            json_body[["mentions"]] <- mentions
        }
        if (length(hosted_content) > 0) {
            json_body[["hostedContents"]] <- hosted_content
        }
        if (length(attach_list) > 0) {
            json_body[["attachments"]] <- attach_list
        }

        # Submit the POST request
        res <- self$post(url, body = json_body)
    },

    #' @description Helps you find the Chat ID of a chat, in case you want to
    #'   send messages to a Chat. This method will only list Chats for which
    #'   you are currently a member.
    #' @param chat_name String - If the Chat has been given a name, you can
    #'   search for its name
    #' @param example_member String - You can share the Display Name of
    #'   somebody in the chat, to help filter down the results. First or Last
    #'   name also works.
    #' @param one_on_one Boolean - True/False indicating whether the Chat is a
    #'   one-on-one Chat or not.
    get_chat_list = function(
        chat_name=NULL,
        example_member=NULL,
        one_on_one=FALSE) {

        # Set up the filter string
        filter <- c()
        if (!is.null(chat_name)) {
            filter <- append(filter, paste0("contains(topic, '",
                                            chat_name,
                                            "')"))
        }
        if (!is.null(example_member)) {
            filter <- append(filter,
                             paste0("members/any(s:contains(s/displayName, '",
                                    example_member,
                                    "'))"))
        }
        if (one_on_one == TRUE) {
            filter <- append(filter, paste0("chatType eq 'oneOnOne'"))
        }

        # Get the list of chats
        url <- "/me/chats?$expand=members"
        if (length(filter) > 0) {
            url <- paste0(url, "&$filter=", paste(filter, collapse = " and "))
        }
        res <- self$get(url)

        lapply(res$value, function(i) {
            list(
                id = i$id,
                topic = i$topic,
                chatType = i$chatType,
                groupSize = length(i$members),
                members = lapply(i$members, function(j) {
                    list(
                        name = j$displayName,
                        email = j$email
                    )
                })
            )
        })
    }

),

private = list(

))
