# Key variable: the Azure AD Application through which we will be acquiring
# our Auth Tokens. If the application is ever changed, this ID needs to be
# updated. Currently tied to the Application OYO-Python and R. We have
# different Tenant IDs for each Tenant.
.AZURE_ID_REF <- list(
    OYO = list(
        tenant_id = "04ec3963-dddc-45fb-afb7-85fa38e19b99",
        app_id = "7c8cca7c-7351-4d57-b94d-18e2ba1e4e24"
    ),
    OVH = list(
        tenant_id = "ad0a533f-0117-494e-93f1-1ba98a9fd13c",
        app_id = "d7aad037-aacb-47e8-9953-3fd6c906216e"
    )
)

# One Blob container to store everybody's Auth tokens.
.AZURE_BLOB_ENDPOINT <- "https://stephenlee.blob.core.windows.net"
.AZURE_BLOB_CONTAINER <- "tokens"
