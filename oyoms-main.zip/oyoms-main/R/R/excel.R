#' Client for interacting with OneDrive Excel Workbook
#'
#' @description
#' Constructs a custom HTTP Client to be used for requests against an Excel
#'   Workbook. The requests methods here are augmented with the usage of
#'   Session IDs to make sequences of API calls as efficient as possible.
#'
#' This Client will act on behalf of an Azure User via an application
#'   registered through Azure AD.
#'
#' @field url The Share Link to the targeted Excel Workbook.
#' @field drive_item The Drive Item represented as a named list.
#'
#' @export
workbook_client <- R6::R6Class("workbook_client", inherit = core_client,

public = list(

    url = NULL,
    drive_item = NULL,

    #' @description Create a new Workbook Client. You provide either the user
    #'   or an auth_config.
    #' @param config An instance of auth_config, or the username string.
    #' @param url The Share Link to the targeted Excel Workbook.
    #' @param drive_item Optional DriveItem dictionary, if the Item is known.
    initialize = function(config, url="", drive_item=NULL) {

        self$url <- url
        self$drive_item <- drive_item

        scopes <- c("https://graph.microsoft.com/files.readwrite.all")
        super$initialize(config, scopes = scopes)

        private$refresh_session_id()
    },

    #' @description Best practice is to close the Session when finished.
    close_session = function(){
        if (!is.null(private$session_id)) {
            res <- self$post("/closeSession")
        }
    },

    #' @description Acquire a list of sheet names belonging to the Workbook.
    get_sheet_list = function(){
        sapply(self$get("/worksheets?$select=name")$value, function(i) i$name)
    },

    #' @description Acquire a spreadsheet_client representing one Worksheet.
    #' @param sheet_name Name of the desired sheet.
    get_sheet = function(sheet_name){
        spreadsheet_client$new(sheet_name, self)
    },

    #' @description Create a new sheet with the desired name.
    #' @param sheet_name Name of the desired sheet.
    create_sheet = function(sheet_name){
        if (!sheet_name %in% self$get_sheet_list()) {
            res <- self$post("/worksheets", body = list(name = sheet_name))
        }
    },

    #' @description Given a sheet (and possibly a range address), extract the
    #'   Used Range information, namely the address, number of rows, and number
    #'   of columns. Returns a named list with items address,
    #'   rowCount, columnCount
    #' @param sheet_name Name of the desired sheet.
    #' @param range_address Optional string with the Range address (A1 format).
    get_used_range_info = function(sheet_name, range_address=NULL){
        # Construct the URL and make the API Call for the data
        if (is.null(range_address)) {
            url <- paste0("/worksheets/",
                          sheet_name,
                          "/usedRange(valuesOnly=true)")
        } else {
            url <- paste0("/worksheets/",
                          sheet_name,
                          "/range(address='",
                          range_address,
                          "')/usedRange(valuesOnly=true)")
        }
        self$get(paste0(url, "?$select=address,rowCount,columnCount"))
    },

    #' @description Read the data from a given range, provided a Sheet name and
    #'   (optional) Range Address. Returns a Tibble/data.frame.
    #' @param sheet_name Name of the desired sheet.
    #' @param range_address Optional string with the Range address (A1 format).
    #' @param na Optional List of Excel errors to explicitly replace as NaN.
    #' @param chunk_size Optional Chunk size in # of cells. Used to handle read
    #'   requests that are too large.
    #' @param ... Optional inputs to the `readr::read_csv` function.
    get_range_data = function(
        sheet_name,
        range_address=NULL,
        na=NULL,
        chunk_size=500000,
        ...) {
        # Get the range address, so we can chunk up the read action
        range_info <- self$get_used_range_info(sheet_name,
                                               range_address = range_address)
        if (is.null(range_info)) stop("Unable to retrieve sheet!")
        address <- tail(strsplit(range_info$address, "!")[[1]], n = 1)
        rows <- range_info$rowCount
        cols <- range_info$columnCount

        # Calculate the row chunk size, and read the data in chunks
        row_chunk_size <- chunk_size %/% cols
        res <- c()
        for (i in seq(1, rows, by = row_chunk_size)) {
            ul <- xl_shift_cell(address, row_shift = (i - 1))
            br <- xl_shift_cell(
                address,
                row_shift = min(i + row_chunk_size - 2, rows - 1),
                col_shift = (cols - 1))
            res <- append(
                res,
                self$get(paste0("/worksheets/",
                                sheet_name,
                                "/range(address='",
                                ul,
                                ":",
                                br,
                                "')?$select=text"))$text
            )
        }

        # Convert incoming data to a CSV string, read it with read_csv
        # for free type inferencing
        csv_str <- paste(
            purrr::map(res, ~ paste(., collapse = "\U001F")), collapse = "\n")

        # Convert specified strings to NA
        if (is.null(na)) {
            na = c("",
                   "#DIV/0!",
                   "#N/A",
                   "#NAME?",
                   "#NULL!",
                   "#NUM!",
                   "#REF!",
                   "#VALUE!",
                   "#SPILL!")
        }

        readr::read_delim(I(csv_str), delim = "\U001F", na = na, ...)
    },

    #' @description Clear the data on a given sheet, with the option of
    #' clearing only a specific range. If the range is not given, the full
    #' sheet will be cleared.
    #' @param sheet_name Name of the desired sheet.
    #' @param range_address Optional string with the Range address (A1 format).
    #' @param apply_to Type of clear. Must be 'All', 'Format', or 'Contents'.
    clear_range = function(sheet_name, range_address=NULL, apply_to="All") {
        if (is.null(range_address)) {
            url <- paste0("/worksheets/", sheet_name, "/usedRange/clear")
        } else {
            url <- paste0("/worksheets/",
                          sheet_name,
                          "/range(address='",
                          range_address,
                          "')/usedRange/clear")
        }

        res <- self$post(url, body = list(applyTo = apply_to))
    },

    #' @description Delete the data on a given sheet, with the option of
    #' deleting only a specific range. If the range is not given, the full
    #' sheet will be deleted.
    #' @param sheet_name Name of the desired sheet.
    #' @param range_address Optional string with the Range address (A1 format).
    #' @param shift How to shift remaining ranges. Must be 'Up' or 'Left'.
    delete_range = function(sheet_name, range_address=NULL, shift="Up") {
        if (is.null(range_address)) {
            url <- paste0("/worksheets/", sheet_name, "/usedRange/delete")
        } else {
            url <- paste0("/worksheets/",
                          sheet_name,
                          "/range(address='",
                          range_address,
                          "')/usedRange/delete")
        }

        res <- self$post(url, body = list(shift = shift))
    },

    #' @description Write one value to a cell/range. Creates the sheet first if
    #'   the sheet does not exist.
    #' @param sheet_name Name of the desired sheet.
    #' @param range_address String with the Cell/Range address (A1 format).
    #' @param value Value to write to the cell.
    write_value = function(sheet_name, range_address, value) {
        self$create_sheet(sheet_name)
        url <- paste0("/worksheets/",
                      sheet_name,
                      "/range(address='",
                      range_address,
                      "')")
        res <- self$patch(url, body = list(values = value))
    },

    #' @description Write a DataFrame to a sheet. Can select location if
    #' desired, default is A1. Please note that large DataFrames will be
    #' uploaded in chunks of 250,000 cells by default. Depending on the data
    #' types of your data, you may need to select a custom chunk-size to avoid
    #' API size limit errors.
    #' @param sheet_name Name of the desired sheet.
    #' @param data data.frame with the input data to be written.
    #' @param location Address of the Upper Left square of the target Range for
    #'   the data. Default is A1.
    #' @param include_header Optional Boolean indicating whether the data's
    #'   header should be written. Defaults to TRUE.
    #' @param chunk_size Size of the chunks with respect to number of cells
    write_data = function(
        sheet_name,
        data,
        location="A1",
        include_header=TRUE,
        chunk_size=250000) {

        self$create_sheet(sheet_name)

        # Converting data.frame into list of lists
        data_list <- purrr::transpose(purrr::map(data, as.list))
        data_list <- lapply(data_list, unname)
        data_list <- lapply(data_list, function(x) replace(x, is.na(x), ""))

        if (include_header == TRUE) {
            data_list <- purrr::prepend(data_list, list(as.list(names(data))))
        }

        # Upload the data in chunks
        rows <- length(data_list)
        cols <- ncol(data)
        row_chunk_size <- chunk_size %/% cols
        for (i in seq(1, rows, by = row_chunk_size)) {
            chunk <- data_list[i:min((i + row_chunk_size - 1), rows)]
            chunk_start <- xl_shift_cell(location, row_shift = (i - 1))
            chunk_end <- xl_shift_cell(
                chunk_start,
                row_shift = min(row_chunk_size, length(chunk) - 1),
                col_shift = (cols - 1))
            chunk_range <- paste(chunk_start, chunk_end, sep = ":")

            url <- paste0("/worksheets/",
                          sheet_name,
                          "/range(address='",
                          chunk_range,
                          "')")
            self$patch(url, body = list(values = chunk))
        }
    },

    #' @description Append a DataFrame to a sheet. Can select a first column if
    #' desired, default is Column A. This method will try to automatically
    #' detect the endpoint of the existing data, and append from there. Please
    #' note that large DataFrames will be uploaded in chunks of 250,000 cells
    #' by default. Depending on the data types of your data, you may need to
    #' select a custom chunk-size to avoid API size limit errors.
    #' @param sheet_name Name of the desired sheet.
    #' @param data data.frame with the input data to be written.
    #' @param first_column First column of the target Range for the data.
    #'   Default is A.
    #' @param include_header Optional Boolean indicating whether the data's
    #'   header should be written. Defaults to FALSE.
    #' @param chunk_size Size of the chunks with respect to number of cells.
    append_data = function(
        sheet_name,
        data,
        first_column="A",
        include_header=FALSE,
        chunk_size=250000) {

        self$create_sheet(sheet_name)
        new_loc <- tryCatch(
            {
                url = paste0("/worksheets/",
                             sheet_name,
                             "/range(address='",
                             first_column,
                             ":",
                             first_column,
                             "')/usedRange/Lastcell?$select=address")
                used_address <- tail(strsplit(self$get(url)$address, "!")[[1]],
                                     n = 1)
                xl_shift_cell(used_address, row_shift = 1)
            },
            error = function(e) {
                paste0(first_column, "1")
            }
        )

        if (new_loc == paste0(first_column, "1")) {
            include_header <- TRUE
        }

        self$write_data(sheet_name,
                        data,
                        location = new_loc,
                        include_header = include_header,
                        chunk_size = chunk_size)
    },

    #' @description All WorkbookClient methods only work on .xlsx files. We
    #'   provide this read_csv method to allow users to read .csv files.
    #' @param ... Optional inputs to the `readr::read_csv` function.
    read_csv = function(...) {
        url <- paste("/drives",
                      private$drive_id,
                      "items",
                      private$item_id,
                      "content",
                      sep = "/")
        res <- AzureGraph::call_graph_endpoint(self$token, url)
        readr::read_csv(I(rawToChar(res)), ...)
    },

    #' @description Save a copy of the Excel Workbook to OneDrive. If a new
    #'   destination folder is not specified, then a copy will be saved in the
    #'   same folder. Name conflicts will automatically be renamed.
    #' @param new_name Optional String specifying a new name. If no extension
    #'   provided, .xlsx is assumed.
    #' @param destination Optional String specifying the Folder to which the
    #'   file will be saved.
    #' @param drive_root Optional String specifying the Drive to which the
    #'   Folder will be located.
    save_as = function(
        new_name=NULL,
        destination=NULL,
        drive_root="/me/drive/root") {

        body <- list(`@microsoft.graph.conflictBehavior` = "rename")

        if (!is.null(new_name)) {
            if (endsWith(new_name, ".csv") | endsWith(new_name, ".xlsx")) {
                body[["name"]] <- new_name
            } else {
                body[["name"]] <- paste0(new_name, ".xlsx")
            }
        }

        if (!is.null(destination)) {
            dc <- drive_client$new(self$config)
            folder <- dc$get_folder(destination, drive_root = drive_root)
            body[['parentReference']] <- list(
                driveId = folder$drive_id,
                id = folder$item_id
            )
        }

        url <- paste0("/drives/",
                     private$drive_id,
                     "/items/",
                     private$item_id,
                     "/copy")
        AzureGraph::call_graph_endpoint(self$token,
                                        url,
                                        http_verb = "POST",
                                        body = body)
    },

    #' @description Grant access to the entire organization. Users who navigate
    #'   to the Excel file will be granted the desired access (either 'edit' or
    #'   'view', default is 'view'). This method returns a Share URL which can
    #'   be distributed if needed.
    #' @param access_type String 'edit' or 'view' indicating access type.
    #'   Default is 'view'.
    share_with_org = function(access_type="view") {
        if (!access_type %in% c('edit', 'view')) {
            stop("Access type must be 'edit' or 'view'")
        }
        body <- list(type = access_type, scope = "organization")
        url <- paste0("/drives/",
                      private$drive_id,
                      "/items/",
                      private$item_id,
                      "/createLink")
        res <- AzureGraph::call_graph_endpoint(self$token,
                                               url,
                                               http_verb = "POST",
                                               body = body)
        res$link$webUrl
    },

    #' @description Grant access to a specific set of users. Users who navigate
    #'   to the Excel file will be granted the desired access (either 'edit' or
    #'   'view', default is 'view'). This method does not return a Share URL.
    #'   Instead, you can set send_email to True to send an email with the
    #'   invitation and share link.
    #' @param user_list List of user email addresses to grant permission.
    #' @param access_type String 'edit' or 'view' indicating access type.
    #'   Default is 'view'.
    #' @param send_email Optional Boolean, send email to users with invitations
    #'   to the sheet (Default False).
    share_with_users = function(
        user_list,
        access_type="view",
        send_email=FALSE) {

        if (!access_type %in% c('edit', 'view')) {
            stop("Access type must be 'edit' or 'view'")
        }
        role <- if (access_type == "view") "read" else "write"
        body = list(
            roles = list(role),
            recipients = lapply(user_list, function(x) list(email = x)),
            sendInvitation = send_email,
            requireSignIn = TRUE
        )
        url <- paste0("/drives/",
                      private$drive_id,
                      "/items/",
                      private$item_id,
                      "/invite")
        AzureGraph::call_graph_endpoint(self$token,
                                        url,
                                        http_verb = "POST",
                                        body = body)
    }

),

private = list(

    # Currently active Session ID, and Drive/Item IDs
    session_id = NULL,
    drive_id = NULL,
    item_id = NULL,

    # The custom resource path for a Workbook points to the specific Drive ID
    # and Item ID. We execute the API call to find these IDs given the Share
    # URL, then we use the IDs to construct the resource path.
    custom_resource_path = function() {
        encode_url <- base64enc::base64encode(charToRaw(self$url))
        encode_url <- gsub("=$", "", encode_url)
        encode_url <- gsub("\\/", "_", encode_url)
        encode_url <- gsub("\\+", "-", encode_url)
        encode_url <- paste0("u!", encode_url)

        if (is.null(self$drive_item)) {
            file_url <- paste0("/shares/", encode_url, "/driveItem")
            self$drive_item <- AzureGraph::call_graph_endpoint(self$token,
                                                               file_url)
        }
        drive_item_list <- get_drive_item_ids(self$drive_item)
        private$drive_id <- drive_item_list$drive_id
        private$item_id <- drive_item_list$item_id

        self$resource_path <- paste0(drive_item_list$url, "/workbook")
    },

    # Create/Refresh the Session ID for enabling maximize efficiency from the
    # Graph API. Without usage of the Session feature, each API call would need
    # to re-locate the file.
    refresh_session_id = function() {
        url <- paste0(self$resource_path, "/createSession")
        tryCatch(
            {
                private$session_id <- AzureGraph::call_graph_endpoint(
                    self$token,
                    url,
                    http_verb = "POST",
                    body = list(persistChanges = TRUE))$id
            },
            error = function(e) {
                private$session_id <- NULL
            }
        )
    },

    # Custom method to perform a request via the client using a Session. If the
    # request fails with a known Session ID error, we refresh the Session and
    # try once more.
    custom_request = function(request_type, path, ...) {
        tryCatch(
            {
                AzureGraph::call_graph_endpoint(
                    self$token,
                    path,
                    http_verb = request_type,
                    httr::add_headers(
                        .headers = c(
                            `workbook-session-id` = private$session_id)),
                    ...)
            },
            error = function(e) {
                if (endsWith(e$message, "The target session is invalid.")) {
                    message("Refreshing Workbook Session...")
                    private$refresh_session_id()
                    AzureGraph::call_graph_endpoint(
                        self$token,
                        path,
                        http_verb = request_type,
                        httr::add_headers(
                            .headers = c(
                                `workbook-session-id` = private$session_id)),
                        ...)
                }
            }
        )
    }
))

#' Client for interacting with a single OneDrive Excel Sheet in a Workbook
#'
#' @description
#' Constructs a custom HTTP Client to be used for requests against an Excel
#'   Worksheet. Intended for convenience, in case a user does not want to
#'   repeatedly include the name of the Sheet in subsequent actions.
#'
#'
#' @field name The name of the Excel Sheet.
#' @field wc The workbook_client that was used to generate this client.
#' @export
spreadsheet_client <- R6::R6Class("spreadsheet_client",

public = list(

    name = NULL,
    wc = NULL,

    #' @description Do not initialize this directly. Create a workbook_client
    #'   first, then use its `get_sheet` method.
    #' @param sheet_name Name of the Excel Sheet.
    #' @param wb_client The workbook_client used to generate this client.
    initialize = function(sheet_name, wb_client) {
        self$name = sheet_name
        self$wc = wb_client

        self$wc$create_sheet(self$name)
    },

    #' @description Extract the Used Range information, from an optional range
    #'   address if desired, namely the address, number of rows, and number
    #'   of columns. Returns a named list with items address,
    #'   rowCount, columnCount
    #' @param range_address Optional string with the Range address (A1 format).
    get_used_range_info = function(range_address=NULL){
        self$wc$get_used_range_info(self$name, range_address = range_address)
    },

    #' @description Read the data from a given range, provided an
    #'   (optional) Range Address. Returns a Tibble/data.frame.
    #' @param range_address Optional string with the Range address (A1 format).
    #' @param na Optional List of Excel errors to explicitly replace as NaN.
    #' @param chunk_size Optional Chunk size in # of cells. Used to handle read
    #'   requests that are too large.
    #' @param ... Optional inputs to the `readr::read_csv` function.
    get_range_data = function(
        range_address=NULL,
        na=NULL,
        chunk_size=500000,
        ...) {
        self$wc$get_range_data(self$name,
                               range_address = range_address,
                               na = na,
                               chunk_size = chunk_size,
                               ...)
    },

    #' @description Clear the data on the sheet, with the option of
    #' clearing only a specific range. If the range is not given, the full
    #' sheet will be cleared.
    #' @param range_address Optional string with the Range address (A1 format).
    #' @param apply_to Type of clear. Must be 'All', 'Format', or 'Contents'.
    clear_range = function(range_address=NULL, apply_to="All") {
        self$wc$clear_range(self$name,
                            range_address = range_address,
                            apply_to = apply_to)
    },

    #' @description Delete the data on the sheet, with the option of
    #' deleting only a specific range. If the range is not given, the full
    #' sheet will be deleted.
    #' @param range_address Optional string with the Range address (A1 format).
    #' @param shift How to shift remaining ranges. Must be 'Up' or 'Left'.
    delete_range = function(range_address=NULL, shift="Up") {
        self$wc$delete_range(self$name,
                            range_address = range_address,
                            shift = shift)
    },

    #' @description Write one value to a cell/range.
    #' @param range_address String with the Cell/Range address (A1 format).
    #' @param value Value to write to the cell.
    write_value = function(range_address, value) {
        self$wc$write_value(self$name, range_address, value)
    },

    #' @description Write a DataFrame to a sheet. Can select location if
    #' desired, default is A1. Please note that large DataFrames will be
    #' uploaded in chunks of 250,000 cells by default. Depending on the data
    #' types of your data, you may need to select a custom chunk-size to avoid
    #' API size limit errors.
    #' @param data data.frame with the input data to be written.
    #' @param location Address of the Upper Left square of the target Range for
    #'   the data. Default is A1.
    #' @param include_header Optional Boolean indicating whether the data's
    #'   header should be written. Defaults to TRUE.
    #' @param chunk_size Size of the chunks with respect to number of cells.
    write_data = function(
        data,
        location="A1",
        include_header=TRUE,
        chunk_size=250000) {

        self$wc$write_data(self$name,
                           data,
                           location = location,
                           include_header = include_header,
                           chunk_size = chunk_size)
    },

    #' @description Append a DataFrame to a sheet. Can select a first column if
    #' desired, default is Column A. This method will try to automatically
    #' detect the endpoint of the existing data, and append from there. Please
    #' note that large DataFrames will be uploaded in chunks of 250,000 cells
    #' by default. Depending on the data types of your data, you may need to
    #' select a custom chunk-size to avoid API size limit errors.
    #' @param data data.frame with the input data to be written.
    #' @param first_column First column of the target Range for the data.
    #'   Default is A.
    #' @param include_header Optional Boolean indicating whether the data's
    #'   header should be written. Defaults to FALSE.
    #' @param chunk_size Size of the chunks with respect to number of cells
    append_data = function(
        data,
        first_column="A",
        include_header=FALSE,
        chunk_size=250000) {

        self$wc$append_data(self$name,
                            data,
                            first_column = first_column,
                            include_header = include_header,
                            chunk_size = chunk_size)
    }
))
