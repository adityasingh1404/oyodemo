#' Client for interacting with Drive
#'
#' @description
#' Constructs a custom HTTP Client to be used for requests for Drive
#'
#' This Client will act on behalf of an Azure User via an application
#'   registered through Azure AD.
#'
#' @export
drive_client <- R6::R6Class("drive_client", inherit = core_client,

public = list(

    #' @description Create a new Drive Client. You provide either the user
    #'   or an auth_config.
    #' @param config An instance of auth_config, or the username string.
    initialize = function(config) {

        scopes <- c("https://graph.microsoft.com/files.readwrite.all")
        super$initialize(config, scopes = scopes)
    },

    #' @description Upload a file to OneDrive. If the file exceeds 4MB, the
    #'   upload automatically gets split into chunks.
    #' @param file_path File for upload. Must be a string path to a local file.
    #' @param target_path Optional Address on the OneDrive to write the file.
    #'   Can be a path to the desired folder, in which case the path should end
    #'   with a forward slash - '/FolderA/FolderB/'; or can be a path with a
    #'   custom filename - '/FolderA/FolderB/FileName.txt'. Default write is to
    #'   the root folder with the same file name.
    #' @param chunk_size Optional chunk upload size in bytes. Only used if file
    #'   exceeds 4MB. Must be a multiple of 327,680 bytes (320 KB)
    #' @param drive_root Optional String specifying a custom drive root
    #'   directory. Default is /me/drive/root:
    upload_file = function(
        file_path,
        target_path=NULL,
        chunk_size=private$DEFAULT_CHUNK_SIZE,
        drive_root="/me/drive/root") {

        # Get file connection and its size
        file_con <- file(file_path, "rb")
        file_size <- file.info(file_path)$size

        # Default target is root path. If input ends with /, it's a folder.
        if (is.null(target_path)) {
            target_path <- basename(file_path)
        } else if (endsWith(target_path, "/")) {
            target_path <- paste0(gsub("^/", "", target_path),
                                  basename(file_path))
        } else {
            target_path <- gsub("^/|/$", "", target_path)
        }

        # URL Prefix for both simple and long uploads
        folder <- self$get_folder(dirname(target_path),
                                  drive_root = drive_root)
        url_prefix <- paste0(folder$url, ":/", basename(target_path))

        if (file_size <= private$UPLOAD_LIMIT) {
            # Simple File Upload
            data <- readBin(file_con, "raw", n = file_size)
            simple_url <- paste0(url_prefix, ":/content")
            res <- self$put(simple_url,
                            body = data,
                            encode = "raw",
                            httr::content_type("application/octet-stream"))
        } else {
            # Chunk Upload - need to open a session and upload in chunks
            res <- self$post(paste0(url_prefix, ":/createUploadSession"),
                             httr::content_type("application/json"))
            session_url <- res$uploadUrl

            current_bytes <- 0
            while (TRUE) {
                # Read a chunk, exit when data upload is done
                data <- readBin(file_con, "raw", n = chunk_size)
                if (length(data) == 0) break

                # Compile the header to track progress
                transfer_bytes <- length(data)
                headers <- c(
                    `Content-Length` = as.character(transfer_bytes),
                    `Content-Range` = paste0(
                        "bytes ",
                        current_bytes,
                        "-",
                        current_bytes + transfer_bytes - 1,
                        "/",
                        file_size
                    ))
                current_bytes <- current_bytes + transfer_bytes

                # Upload the chunk
                res <- httr::VERB("PUT",
                                  session_url,
                                  body = data,
                                  encode = "raw",
                                  httr::add_headers(.headers = headers))

                # Check for errors, break if done
                httr::stop_for_status(res)
                if (res$status_code != 202) {
                    res <- httr::content(res)
                    break
                }
            }
        }

        close(file_con)
        res
    },

    #' @description Retrieve the Drive ID and Item ID of a folder using its
    #'   folder path (and optionally a drive root). Create the folder paths
    #'   if necessary.
    #' @param path String with a path to the folder. Use forward slashes.
    #' @param drive_root Optional String if your drive root is somewhere other
    #'   than your user root.
    get_folder = function(path, drive_root="/me/drive/root") {
        split_path <- function(x) {
            if (dirname(x) == x) x else c(split_path(dirname(x)), basename(x))
        }
        path_chain <- split_path(gsub("^/", "", path))[-1]

        # Start by getting the root
        folder <- get_drive_item_ids(self$get(drive_root))

        # Loop through the chain and try to Get. If Get fails, then Create.
        for (name in path_chain) {
            tryCatch(
                {
                    folder <- get_drive_item_ids(self$get(paste0(folder$url,
                                                                 ":/", name)))
                },
                error = function(e) {
                    body <- list(
                        name = name,
                        folder = setNames(list(), character(0)),
                        `@microsoft.graph.conflictBehavior` = "fail"
                    )
                    folder <<- get_drive_item_ids(
                        self$post(paste0(folder$url, "/children"), body = body))
                }
            )
        }
        folder
    },

    #' @description Take a OneDrive file path and retrieve the Drive Item
    #'   information. Will raise error if Item does not exist.
    #' @param path String with the file path
    #' @param drive_root Optional String if your drive root is somewhere other
    #'   than your user root.
    get_item = function(path, drive_root="/me/drive/root") {
        self$get(paste0(drive_root, ":/", gsub("^/", "", path)))
    },

    #' @description Take a Tibble/data.frame and write it to a CSV on OneDrive.
    #'   Returns a DriveItem dictionary with metadata on the written file.
    #' @param df Tibble/data.frame to write to CSV.
    #' @param target_path Address on the OneDrive to write the CSV. Separate
    #'   folders with forward slashes, for example "/Storage/Folder/data.csv".
    #'   If only a CSV name is provided, then it will be written to the User's
    #'   default Drive.
    #' @param ... Same optional args that can be provided to `readr::write_csv`
    df_to_csv = function(df, target_path, ...) {
        tmp <- tempfile()
        readr::write_csv(df, tmp, ...)
        self$upload_file(tmp, target_path = target_path)
    },

    #' @description Take a Tibble/data.frame and write it to a XLSX on OneDrive.
    #'   Returns a DriveItem dictionary with metadata on the written file.
    #' @param df Tibble/data.frame to write to XLSX
    #' @param target_path Address on the OneDrive to write the XLSX Separate
    #'   folders with forward slashes, for example "/Storage/Folder/data.xlsx".
    #'   If only a XLSX name is provided, then it will be written to the User's
    #'   default Drive.
    #' @param sheet_name Optional sheet name for the data.
    #' @param ... Same optional args that can be provided to
    #'   `openxlsx::writeData`
    df_to_xlsx = function(df, target_path, sheet_name="Sheet1", ...) {
        tmp <- tempfile(fileext = ".xlsx")
        wb <- openxlsx::createWorkbook()
        openxlsx::addWorksheet(wb, sheet_name)
        openxlsx::writeData(wb, sheet_name, df, ...)
        openxlsx::saveWorkbook(wb, tmp)
        self$upload_file(tmp, target_path = target_path)
    }

),

private = list(
    UPLOAD_LIMIT = 1024 * 1024 * 4,  # 4 MB Simple Upload limit
    DEFAULT_CHUNK_SIZE = 1024 * 1024 * 5  # 5 MB Defaul Chunk Size
))
