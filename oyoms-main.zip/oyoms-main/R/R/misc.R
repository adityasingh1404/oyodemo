# Miscellaneous utilities for MS 365 activities.


# Convert an alphabetic column to a numerical column.
# https://stackoverflow.com/a/12640614
xl_col2num <- function(col) {
    num <- 0
    for (c in strsplit(col, "")[[1]]) {
        if (!grepl("[^A-Za-z]", c)) {
            num <- num * 26 + (utf8ToInt(toupper(c)) - utf8ToInt("A")) + 1
        }
    }
    num
}


# Convert a column number to an alphabetic column.
# https://stackoverflow.com/a/23862195
xl_num2col <- function(num) {
    s <- ""
    while (num > 0) {
        rem <- (num - 1) %% 26
        num <- (num - 1) %/% 26
        s <- paste0(intToUtf8(65 + rem), s)
    }
    s
}


# Add a number of columns to an alphabetic Excel column, getting the target
# column name.
xl_add2col <- function(start, addition) {
    xl_num2col(xl_col2num(start) + addition)
}


# Parse an A1-style cell address.  If provided as a range (i.e. B2:D4), will
# ignore the second cell address. Returns two outputs, one string and one
# integer.
xl_parse_cell_address <- function(address) {
    address <- strsplit(address, ":")[[1]][1]
    col <- gsub("[^[:alpha:]]", "", address)
    row <- strtoi(gsub("[^[:digit:]]", "", address))
    list(col = col, row = row)
}

# Accept a cell address, and shift it by a given number of rows and columns,
# returning the final address.
xl_shift_cell <- function(address, row_shift=0, col_shift=0) {
    xl_address <- xl_parse_cell_address(address)
    col <- xl_address$col
    row <- xl_address$row

    new_col <- xl_add2col(col, col_shift)
    new_row <- row + row_shift

    paste0(new_col, new_row)
}

# Extract the Drive ID and Item ID for a DriveItem, and the API endpoint.
get_drive_item_ids <- function(item) {
    drive_id <- item$parentReference$driveId
    item_id <- item$id
    list(
        url = paste0("/drives/", drive_id, "/items/", item_id),
        drive_id = drive_id,
        item_id = item_id
    )
}
