#' Client for interacting with Outlook
#'
#' @description
#' Constructs a custom HTTP Client to be used for requests against an Outlook
#'   Mailbox.
#'
#' This Client will act on behalf of an Azure User via an application
#'   registered through Azure AD.
#'
#' @export
outlook_client <- R6::R6Class("outlook_client", inherit = core_client,

public = list(

  #' @description Create a new Outlook Client. You provide either the user
  #'   or an auth_config.
  #' @param config An instance of auth_config, or the username string.
  initialize = function(config) {

      scopes <- c("https://graph.microsoft.com/mail.readwrite",
                  "https://graph.microsoft.com/mail.send")
      super$initialize(config, scopes = scopes)
  },

  #' @description send mime email message
  #' @param msg mime type email message
  send_msg = function(msg) {
      # encode the mime message in base64
      msg_base64 = base64enc::base64encode(charToRaw(msg))
      url = '/me/sendMail'
      res <- self$post(url, body = msg_base64, httr::content_type("text/plain"), encode = 'raw')
  },


  #' @description Send an email with html or plain-text content type with attachments
  #' @param subject subject of the email as string
  #' @param from_email sender's email address as a string
  #' @param email_body contents of the email in html or text string format
  #' @param to_recipients list of email adresses the email is addressed to
  #' @param cc_recipients list of cc email adresses with default value of None
  #' @param bcc_recipients list of bcc email adresses with default value of None
  #' @param attachments list of attachment file paths strings. Total attachments size should be less than 150MB. Default is None.
  #' @param email_body_type data type of email body which can be either html or plain-text type.
  #' Default is plain-text
  send_mail = function(
      subject,
      from_email,
      email_body,
      to_recipients,
      cc_recipients=NULL,
      bcc_recipients=NULL,
      attachments = NULL,
      email_body_type = "text") {


      to_recipients = paste(to_recipients, collapse = ',')


      # Create email message object
      msg = gmailr::gm_mime()
      msg = gmailr::gm_subject(msg, subject)
      msg = gmailr::gm_to(msg, to_recipients)
      msg = gmailr::gm_from(msg, from_email)

      # Add cc email addresses
      if (!is.null(cc_recipients)){
          cc_recipients = paste(cc_recipients, collapse = ',')
          msg = gmailr::gm_cc(msg, cc_recipients)
      }
      # Add bcc email addresses
      if (!is.null(bcc_recipients)){
          bcc_recipients = paste(bcc_recipients, collapse = ',')
          msg = gmailr::gm_bcc(msg, bcc_recipients)
      }

      # Add email body content
      if (email_body_type == 'html'){
          msg = gmailr::gm_html_body(msg, email_body)
      }
      else {
          msg = gmailr::gm_text_body(msg, email_body)
      }

      # Add attachments
      draft_attachments = c()
      large_attachments = c()

      if (!is.null(attachments)){
          attachments_size = 0
          size_df = data.frame(path=character(),
                          file_size=double())
          size_df$path = as.character(size_df$path)

          for (i in attachments) {
              file_size <- file.info(i)$size
              size_df[nrow(size_df) + 1,] <- c(i, file_size)
          }
          size_df$file_size = as.double(size_df$file_size)
          size_df = size_df[order(size_df$file_size),]

          for (row in 1:nrow(size_df)) {
              path <- size_df[row, "path"]
              file_size  <- size_df[row, "file_size"]
              attachments_size = attachments_size + file_size

              if (attachments_size <= private$UPLOAD_LIMIT){
                  draft_attachments = append(draft_attachments, path)
              }
              else {
                  large_attachments = append(large_attachments, path)
              }
          }

          for (i in draft_attachments) {
              msg = gmailr::gm_attach_file(msg, i)
          }
      }

      # Convert message to base64 format
      msg = as.character(msg)
      msg_base64 = base64enc::base64encode(charToRaw(msg))

      if (is.null(large_attachments)) {
          res <- self$post("/me/sendMail", body = msg_base64, httr::content_type("text/plain"), encode = 'raw')
          }

      else{
          # Create Draft message
          draft_msg = self$post("/me/messages", body = msg_base64, httr::content_type("text/plain"), encode = 'raw')
          msg_id = draft_msg$id

          for (i in large_attachments) {
              self$upload_attachment(msg_id, i)
          }

          # Send message
          headers <- c(
              `Content-Type`= "text/plain",
              `Content-Length` = as.character(0))
          self$post(paste('/me/messages/',msg_id,'/send'), httr::add_headers(.headers = headers))
      }
},

    upload_attachment = function(msg_id, attachment, chunk_size=private$DEFAULT_CHUNK_SIZE) {

        # Chunk Upload - need to open a session and upload in chunks
        file_con <- file(attachment, "rb")
        file_size <- file.info(attachment)$size
        file_name <- basename(attachment)

        data = list(AttachmentItem = list(attachmentType = 'file', name = file_name, size=file_size))

        session_url = self$post(paste(paste('/me/messages/',msg_id),'/attachments/createUploadSession'),
                                httr::content_type("application/json"), body=data)$uploadUrl

        current_bytes <- 0
        while (TRUE) {
            # Read a chunk, exit when data upload is done
            data <- readBin(file_con, "raw", n = chunk_size)
            if (length(data) == 0) break

            # Compile the header to track progress
            transfer_bytes <- length(data)
            headers <- c(
                `Content-Type`= "application/octet-stream",
                `Content-Length` = as.character(transfer_bytes),
                `Content-Range` = paste0(
                    "bytes ",
                    current_bytes,
                    "-",
                    current_bytes + transfer_bytes - 1,
                    "/",
                    file_size
                ))
            current_bytes <- current_bytes + transfer_bytes

            # Upload the chunk
            res <- httr::VERB("PUT",
                              session_url,
                              body = data,
                              encode = "raw",
                              httr::add_headers(.headers = headers))

            # Check for errors, break if done
            httr::stop_for_status(res)
            if (!res$status_code %in% c(200, 201, 202)) {
                res <- httr::content(res)
                break
            }
        }
    }
),

private = list(
    UPLOAD_LIMIT = 1024 * 1024 * 3,  # 3 MB Simple Upload limit
    DEFAULT_CHUNK_SIZE = 1024 * 1024 * 4  # 4 MB Defaul Chunk Size
))
