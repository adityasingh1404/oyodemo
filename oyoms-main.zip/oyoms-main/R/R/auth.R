#' Authorization Configuration for Microsoft access
#'
#' @description
#' This is a small class to wrap a dictionary that dictates how and
#' where to store the Auth Tokens. Sets the default Local config cache.
#'
#' Auth/Refresh Tokens can be cached locally if desired by the user, but to do
#' so, the user must ensure that a local file storage will persist, for example
#' running locally or on a persistent VM.
#'
#' For applications that will be running on non-persistent resources (i.e. spot
#' VMs, clusters), we enable usage of an Azure Blob to store the Token Cache.
#' Accessing the Blob will require either Azure CLI login if being used locally,
#' or Managed Identity login if being used on an Azure VM.
#'
#' @field user User to whom the config will be assigned.
#' @field style Must be either 'local' or 'blob', dictating where to cache
#'   the config.
#' @field client_id String containing the Azure Application ID for the App
#'   requesting tokens.
#' @field tenant String containing the name of the Tenant.
#'
#' @export
auth_config <- R6::R6Class("auth_config",

public = list(

    user = NULL,
    style = NULL,
    client_id = NULL,
    tenant = NULL,

    #' @description An auth_config can be passed to various clients to obtain
    #'   access to their respective services.
    #' @param user User to whom the config will be assigned.
    #' @param style Must be either 'local' or 'blob', dictating where to cache
    #'   the config.
    #' @param tenant Must be either 'OYO' or 'OVH', indicating the tenant.
    #' @param client_id String containing the Azure Application ID for the App
    #'   requesting tokens.
    initialize = function(user, style="local", tenant="OYO", client_id=NULL) {

        if (!style %in% c('local', 'blob')) {
            stop("auth_config style must either be 'local' or 'blob'.")
        }
        if (!tenant %in% names(.AZURE_ID_REF)) {
            stop("Must enter a valid tenant.")
        }

        self$user <- user
        self$style <- style
        self$tenant <- tenant
        self$client_id <- if (is.null(client_id)) {
            .AZURE_ID_REF[[self$tenant]]$app_id
            } else client_id
    },

    #' @description Boolean sharing whether or not the AuthConfig is local.
    is_local = function() {
        self$style == "local"
    }
))


# Device Code Flow Credential Object
#
# Authentication Flow to enable browser-less deployment. User will be given a
#   link to submit to a browser on an (optionally) separate device.

device_code_credential <- R6::R6Class("device_code_credential",

public = list(

    config = NULL,
    cached_token = NULL,
    cache_dir = NULL,

    initialize = function(config) {
        self$config <- config

        # Force creation of the default local cache directory
        self$cache_dir <- rappdirs::user_data_dir(appname = "AzureR",
                                                  appauthor = "",
                                                  roaming = FALSE)
        if (!dir.exists(self$cache_dir)) {
            dir.create(self$cache_dir, recursive = TRUE)
        }

        if (!self$config$is_local()) {
            private$manage_cloud_cache()
        }
    },

    # Primary method to obtain an Auth token via the AzureAuth library.
    get_token = function(scopes) {
        for (s in c("offline_access", "openid", "profile")) {
            if (!s %in% scopes) {
                scopes <- append(scopes, s)
            }
        }
        token <- AzureAuth::get_azure_token(
            scopes,
            .AZURE_ID_REF[[self$config$tenant]]$tenant_id,
            self$config$client_id,
            auth_type = "device_code",
            version = 2,
            token_args = c(account_id = self$config$user))

        # Upload token to cloud if needed
        if (!self$config$is_local() & !is.null(private$azure_cont)) {
            private$upload_cloud_token(token)
        }

        token
    }
),

private = list(

    azure_cont = NULL,

    get_user_name = function() {
        unlist(strsplit(self$config$user, "@"))[1]
    },

    manage_cloud_cache = function() {
        print("Connecting to Azure Blob...")

        # Acquire an Azure Storage token either through Managed Identity
        # or Device Code Flow
        tryCatch({
            blob_token <- AzureAuth::get_managed_token(
                "https://storage.azure.com")
            private$blob_folder_download(blob_token)
        }, error = function(e) {
            tryCatch({
                blob_token <- self$get_token(
                    "https://storage.azure.com/.default")
                private$blob_folder_download(blob_token)
            }, error = function(e) {
                print("Unable to acquire DFC auth")
                stop("Unable to download token from Azure Blob")
            })
        })
    },

    # Rather than figuring out exactly which token to download, get them all
    blob_folder_download = function(blob_token) {
        blob <- AzureStor::storage_endpoint(
            .AZURE_BLOB_ENDPOINT,
            token = blob_token)
        cont <- AzureStor::storage_container(blob, .AZURE_BLOB_CONTAINER)
        AzureStor::storage_multidownload(
            cont,
            src = paste0(private$get_user_name(), "/*"),
            dest = self$cache_dir,
            overwrite = TRUE
        )

        private$azure_cont <- cont
    },

    # After we refresh the token, we update the copy in the cloud
    upload_cloud_token = function(token) {
        AzureStor::storage_upload(
            private$azure_cont,
            src = file.path(self$cache_dir, token$hash()),
            dest = paste(private$get_user_name(), token$hash(), sep = "/"))
    }
))
