# Script for creating/updating a local repository
# Reference: https://rstudio.github.io/packrat/custom-repos.html

# Set up the repo folder
repo_address <- file.path(Sys.getenv("HOME"), "OYOMS_R_REPO")
if (!dir.exists(repo_address)) {
    dir.create(repo_address, recursive = TRUE)
}

# Currently, we'll only deal in Source files. Can expand
# later to binaries if we need to.
contrib_dir <- file.path(repo_address, "src", "contrib")
if (!dir.exists(contrib_dir)) {
    dir.create(contrib_dir, recursive = TRUE)
}

# Build the package to the source directory
devtools::build(path = contrib_dir)

# Update the package info
tools::write_PACKAGES(contrib_dir, type = "source")
