library(testthat)
library(oyoms)

test_check("oyoms")
