# Try getting an email
get_email <- function() {
    config <- auth_config$new("test@oyorooms.com", style = "local")
    oc <- outlook_client$new(config = config)
    res <- oc$get("/me/messages")
    res$value[[1]]$subject
}

test_that("Message subject header is retrieved", {
    expect_equal(class(get_email()), "character")
})

# Try reading a sheet
get_sheet <- function() {
    config <- auth_config$new("test@oyorooms.com", style = "local")
    share_url <- 'https://oyoenterprise-my.sharepoint.com/:x:/g/personal/stephen_lee_oyorooms_com/EU1EznaA78hRtmXzkfD7bSoBOp1_zZT57B1i3OoNf7ICBA?e=USjSw2'
    wc <- workbook_client$new(config = config, url = share_url)
    wc$get_sheet_list()
}

test_that('Excel sheet list is retrieved', {
    expect_equal(class(get_sheet()), "character")
})

# Try writing a sheet
write_sheet <- function() {
    config <- auth_config$new("test@oyorooms.com", style = "local")
    share_url <- 'https://oyoenterprise-my.sharepoint.com/:x:/g/personal/stephen_lee_oyorooms_com/EU1EznaA78hRtmXzkfD7bSoBOp1_zZT57B1i3OoNf7ICBA?e=USjSw2'
    wc <- workbook_client$new(config = config, url = share_url)
    df <- data.frame(name = c('a','b','c'), val = c(1,2,3))
    wc$write_data("Test Sheet", df, "F1")

    1
}

test_that('Excel write is successful', {
    expect_equal(write_sheet(), 1)
})
