library(oyoms)

# Try getting an email
config <- auth_config$new("test@oyorooms.com", style = "local")
oc <- outlook_client$new(config = config)
res <- oc$get("/me/messages")

print(res$value[[1]]$subject)

# Try reading a sheet
share_url <- 'https://oyoenterprise-my.sharepoint.com/:x:/g/personal/stephen_lee_oyorooms_com/EU1EznaA78hRtmXzkfD7bSoBOp1_zZT57B1i3OoNf7ICBA?e=USjSw2'
wc <- workbook_client$new(config = config, url = share_url)

print(wc$get_sheet_list())
