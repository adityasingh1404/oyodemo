# OYO MS Python/R Package for Accessing Microsoft 365.

The [Microsoft Graph API](https://docs.microsoft.com/en-us/graph/use-the-api) is the primary tool for 
interacting with cloud-based Microsoft Office tools such as OneDrive Excel, Outlook, and more.
This Python/R package serves as a wrapper of the Graph API for OYO Developers to serve use cases such as 
automated writing to shared OneDrive Excel files.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Installation](#installing-the-package)
- [Auth Tokens](#auth-tokens)
- [Excel Access](#onedrive-excel-access)
- [Drive Access](#onedrive-files-access)
- [Teams Access](#teams-access)
- [Outlook Access](#outlook-access)
- [Example: From Data To Teams](#dataframe-to-teams-example)  
- [For Developers](#for-developers)
- [Issues](#issues)


## Prerequisites
__VPN__: The Python/R packages are hosted on an OYO Virtual Machine, so a VPN will be required
to gain `pip install`/`install.packages` access. If your current VPN is not working, please contact 
DevOps to update to the correct VPN.

__Python Version__: Python 3.6+

__R Version__: R 3.3+

## Installing the package

The package is hosted on an internal Virtual Machine, so the install commands are more involved.
The Python package installation requires a username/password, which can be found 
[here](https://knowledge.oyorooms.com/books/machine-learning-platform/page/turing-package-installation).

Python:
```cmd
pip install oyoms -i https://nexus.oyorooms.io/repository/pypi.oyorooms.com/simple/ --trusted-host=nexus.oyorooms.io:443 -vU
```

R:

```r
install.packages("oyoms", type = "source", repos = "http://10.50.50.130:9000", dependencies = TRUE)
```

You must be connected to the appropriate VPN for this to work.

## Auth Tokens

As you use `oyoms`, the code will prompt you to log in via a web browser. After you log in, a Microsoft 
Authentication token is downloaded on your behalf and cached for future use. Depending on your use case,
you may want this token cached either locally or in the cloud.

__Important__: Auth Tokens expire when your account's password is reset, or after 90 days of inactivity. 
When the token is expired, the user will need to log in manually once again - this action will refresh 
the Auth Token. This issue is particularly relevant for users who plan to deploy automated scripts.

__Recommendation__: The best practice is to use designated "Service Accounts" which belong to teams 
rather than individuals. This way, any team member can refresh the Auth Token in the event that the
original coder leaves the team or is unavailable to perform the refresh. For personal use cases,
you are free to use your own account - but be mindful that teammates will not be able to refresh
your Tokens in the event of a password reset.

### Using Default Local Token Caching
To use the default Local token caching, simply pass in the Account to your Client object.
The Token will be cached in a default location.

Python:
```python
import oyoms as om
dc = om.DriveClient('account@oyorooms.com')
```

R:
```r
library(oyoms)
dc <- drive_client$new("account@oyorooms.com")
```

### Working in the OVH Tenant
By default, this package operates within the OYO Tenant. In order to access Microsoft 365 resources in the OVH Tenant,
you must have either an OVH account, or have been granted the necessary Guest permissions.
To configure the `oyoms` Clients to work with OVH, you must provide configurations via the AuthConfig object.

```python
import oyoms as om
config = om.AuthConfig('account@oyorooms.com', tenant='OVH')
dc = om.DriveClient(config)
```

```r
library(oyoms)
config <- auth_config$new("account@oyorooms.com", tenant = "OVH")
dc <- drive_client$new(config)
```


### Using Customized Local Token Caching
To use customized Local token caching, you must use an AuthConfig instance. With the AuthConfig
object, you can specify choices such as Token Cache location, and cache file name. 
*Note:* This functionality is not currently supported in R.  

Python:
```python
import oyoms as om
config = om.AuthConfig('account@oyorooms.com', style='local', path='custom/path/to/cache/', cache_name='my_cache.bin')
dc = om.DriveClient(config)
```

### Using Cloud Token Caching [NOT YET AVAILABLE]
To use the Cloud token cache method, you will need to log in to 
[Azure CLI](https://docs.microsoft.com/en-us/cli/azure/) for the token caching to work. Your account needs to be 
granted access to the core Azure Blob used by `oyoms` to store tokens. Contact DevOps to acquire this access. 
When your code runs on a Virtual Machine, where you might not be able to use the Azure CLI log in, the use of Microsoft
[Managed Identities](https://docs.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview)
can provide Azure Blob access.

To use the Blob token caching, you need to provide an Auth Config instance to the Client with the `style`
field set to `'blob'`.

Python:
```python
import oyoms as om
config = om.AuthConfig('account@oyorooms.com', style='blob')
dc = om.DriveClient(config)
```

R:
```r
library(oyoms)
config <- auth_config$new("account@oyorooms.com", style = "blob")
dc <- drive_client$new(config)
```

## OneDrive Excel Access

Communication with OneDrive Excel through the Microsoft Graph API is provided through our Workbook Client
object. Simply provide the Share Link to the OneDrive Excel file to connect the Client with your Excel file.

**Note**: This package does **not** support interaction with local Excel files. For local interaction
we recommend an existing open-source package such as `openpyxl`.

### Supported Excel Actions (.xlsx files only)
Once you create the Workbook Client, you can perform a range of common Excel tasks.
**Note**: The Excel file must be shared with the account you configure.

Python:
```python
import oyoms as om
excel_link = 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb = om.WorkbookClient('account@oyorooms.com', excel_link)

# Get the list of sheets
wb.get_sheet_list()

# Create a new sheet
wb.create_sheet('My Sheet')

# Pull address info on a sheet's data
address, rows, cols = wb.get_used_range_info('My Sheet')

# Pull a sheet's data into a Pandas DataFrame
df = wb.get_range_data('My Sheet')

# Clear an existing range of data
wb.clear_range('My Sheet')

# Delete an existing range of data
wb.delete_range('My Sheet')

# Write a single value
wb.write_value('My Sheet', range_address='A1', value=42)

# Write a DataFrame
wb.write_data('My Sheet', df)

# Append a DataFrame to existing data in a sheet
wb.append_data('My Sheet', df)

# Tired of writing the sheet name? All of the above methods work on a Spreadsheet Client
sh = wb.get_sheet('My Sheet')
sh.clear_range()
sh.write_data(df)

# Best practice is to close the Session when finished
wb._close_session()
```

R:
```r
library(oyoms)
excel_link <- 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb <- workbook_client$new("account@oyorooms.com", excel_link)

# Get the list of sheets
wb$get_sheet_list()

# Create a new sheet
wb$create_sheet("My Sheet")

# Pull address info on a sheet's data
info <- wb$get_used_range_info("My Sheet")

# Pull a sheet's data into a tibble
df <- wb$get_range_data("My Sheet")

# Clear an existing range of data
wb$clear_range("My Sheet")

# Delete an existing range of data
wb$delete_range("My Sheet")

# Write a single value
wb$write_value("My Sheet", range_address="A1", value=42)

# Write a data.frame
wb$write_data("My Sheet", df)

# Append a data.frame to existing data in a sheet
wb$append_data("My Sheet", df)

# Tired of writing the sheet name? All of the above methods work on a Spreadsheet Client
sh <- wb$get_sheet("My Sheet")
sh$clear_range()
sh$write_data(df)

# Best practice is to close the Session when finished
wb$close_session()
```

### Reading CSV files from OneDrive
The WorkbookClient object can also be passed a Share Link to a `.csv` file, 
but the only functionality we support is the `read_csv` method.
If your goal is to edit a CSV file and have the changes reflected on OneDrive, 
then you can use `read_csv` to download the CSV, perform your edits in Python/R, 
then upload the CSV to OneDrive using the DriveClient's `df_to_csv` method.

```python
import oyoms as om
csv_link = 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb = om.WorkbookClient('account@oyorooms.com', csv_link)
df = wb.read_csv()
```

```r
library(oyoms)
csv_link <- 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb <- workbook_client$new("account@oyorooms.com", csv_link)
df <- wb$read_csv()
```

### Adding Permissions

You can add either organization wide edit/view access, or provide access to a specific set of users.
```python
import oyoms as om
excel_link = 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb = om.WorkbookClient('account@oyorooms.com', excel_link)

# Org-wide access
share_url = wb.share_with_org(access_type='edit')

# User access
wb.share_with_users(['user1@oyorooms.com', 'user2@oyorooms.com'], access_type='view', send_email=True)
```

```r
library(oyoms)
excel_link <- 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb <- workbook_client$new("account@oyorooms.com", excel_link)

# Org-wide access
share_url <- wb$share_with_org(access_type = "edit")

# User access
wb$share_with_users(c("user1@oyorooms.com", "user2@oyorooms.com"), access_type = "view", send_email = TRUE)
```

### Saving a Workbook to a New Location

You can save an open WorkbookClient to a new Excel file on OneDrive.

```python
import oyoms as om
excel_link = 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb = om.WorkbookClient('account@oyorooms.com', excel_link)
wb.save_as(new_name='new.xlsx', destination='New Folder')
```

```r
library(oyoms)
excel_link <- 'https://oyoenterprise-my.sharepoint.com/:x:/r/abcdefghijklmnopqrstuvwxyz'
wb <- workbook_client$new("account@oyorooms.com", excel_link)
wb$save_as(new_name = "new.xlsx", destination = "New Folder")
```


## OneDrive Files Access
Communication with OneDrive file storage is provided through our Drive Client object.

### Supported Drive Actions

We support generic file upload to OneDrive file storage. The file to upload must be provided via a local filepath.
You can generally provide a target location via the `target_path` parameter. If you provide a folder that does
not yet exist, the DriveClient will create it for you.

```python
import oyoms as om
dc = om.DriveClient('account@oyorooms.com')
dc.upload_file('/path/to/local/file/to/upload.txt')
```

```r
library(oyoms)
dc <- drive_client$new("account@oyorooms.com")
dc$upload_file("/path/to/local/file/to/upload.txt")
```

We also support direct upload of a Pandas DataFrame or an R Tibble/data.frame to a CSV or XLSX file on OneDrive.

```python
import oyoms as om
import pandas as pd
dc = om.DriveClient('account@oyorooms.com')
df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
dc.df_to_csv(df, 'folder/test.csv')
dc.df_to_xlsx(df, 'folder/test.xlsx')
```

```r
library(oyoms)
library(tibble)
dc <- drive_client$new("account@oyorooms.com")
df <- tibble(x = 1:3, y = 4:6)
dc$df_to_csv(df, "folder/test.csv")
dc$df_to_xlsx(df, "folder/test.xlsx")
```

## Teams Access
Communication with Teams is provided through our Teams Client object.

### Supported Teams Actions

We support message sending to Teams channels and chats, including images and attachments. 
To direct the Teams Client to a desired channel, locate the channel in Teams, click on the `...` button,
and click _Get link to channel_. This link can then be provided to the `send_message` method into 
the `channel_url` argument. The message string can be in HTML format, if desired.

You can tag people in the message by using their email address in the pattern `$TAG(user@oyorooms.com)`.
When messaging a Channel, you can tag the Channel in the message by using the pattern `$TAG(channel)`.

If the Channel only provides the _Get email address_ option, then you can instead use the Outlook Client
to send an email to the Channel (this approach currently does not support User Tagging).

For convenience, the elements of the `attachments` list can also be instances of the Workbook Client,
to directly link to OneDrive Excel files.

```python
import oyoms as om
tc = om.TeamsClient('account@oyorooms.com')
tc.send_message('Message to send $TAG(user@oyorooms.com)', 
                channel_url='teams/channel/link',
                images=['/path/to/image/file.png'],
                attachments=['/path/to/attachments/file.csv'])
```

```r
library(oyoms)
tc <- teams_client$new("account@oyorooms.com")
tc$send_message("Message to send $TAG(user@oyorooms.com)", 
                channel_url = "teams/channel/link", 
                images = c("/path/to/image/file.png"),
                attachments = c("/path/to/attachments/file.csv"))
```

To send a message to a Chat, you need to obtain the Chat ID. You can use the `get_chat_list` method
to search for your particular Chat ID:

```python
import oyoms as om
tc = om.TeamsClient('account@oyorooms.com')
chat_list = tc.get_chat_list(chat_name='Chat Name', example_member='Stephen', one_on_one=False)
chat_id = chat_list[0].get('id')
tc.send_message('Message to send $TAG(user@oyorooms.com)', chat_id=chat_id)
```

```r
library(oyoms)
tc <- teams_client$new("account@oyorooms.com")
chat_list <- tc$get_chat_list(chat_name = "Chat Name", example_member = "Stephen", one_on_one = FALSE)
chat_id <- chat_list[[1]]$id
tc$send_message("Message to send $TAG(user@oyorooms.com)", chat_id = chat_id)
```


## Outlook Access
Communication with MS Outlook is provided through our Outlook Client object.

### Supported Outlook Actions

This client supports sending emails from an outlook account. The email to be sent can be of MIME type or 
it can be constructed using desired email attributes. It supports multiple recipients and attachments 
of upto a total size of 150MB. The email body can be either of plain text or HTML format.

send_mail method is to be used when constructing the email from scratch.

```python
import oyoms as om
oc = om.OutlookClient('account@oyorooms.com')
oc.send_mail(
subject = 'Sample Subject',
email_body = 'Hello World!',
from_email = 'x@outlook.com',
to_recipients = 'y@outlook.com',
cc_recipients = ['a@outlook.com','b@outlook.com'],
attachments = ['file1.csv','file2.png']
)

```

```r
library(oyoms)
oc <- outlook_client$new("account@oyorooms.com")
oc$send_mail(
        subject = 'Sample Subject',
        email_body = 'Hello World!',
        from_email = 'x@outlook.com',
        to_recipients = 'y@outlook.com',
        cc_recipients = ['a@outlook.com','b@outlook.com'],
        attachments = ['file1.csv','file2.png'])
```

email_body_type argument can be used for constructing email with HTML email body

```python
oc.send_mail(
subject = 'Sample Subject',
email_body = """<html>
                 <head>
                 </head>
                 <body>
                   <h1>Hello World<h1>
                 </body>
                </html>
             """ ,
from_email = 'x@outlook.com',
to_recipients = 'y@outlook.com',
cc_recipients = ['a@outlook.com','b@outlook.com'],
attachments = ['file1.csv','file2.png'], 
email_body_type = 'html'
)

```
```r
library(oyoms)
oc <- outlook_client$new("account@oyorooms.com")

oc$send_mail(
        subject = 'Sample Subject',
        email_body = """<html>
                         <head>
                         </head>
                         <body>
                           <h1>Hello World<h1>
                         </body>
                        </html>
                     """ ,
        from_email = 'x@outlook.com',
        to_recipients = 'y@outlook.com',
        cc_recipients = ['a@outlook.com','b@outlook.com'],
        attachments = ['file1.csv','file2.png'], 
        email_body_type = 'html')
```

If sending MIME type email message send_msg 
method is to be used. send_msg method supports attachments of size upto 3MB.

```python
oc.send_msg(mime_msg)
```
```r
oc$send_msg(mime_msg)
```

## DataFrame to Teams Example

Here is an example pipeline to go from a Pandas/R DataFrame all the way to an Excel attachment in Teams.

```python
import oyoms as om
import pandas as pd

# Set up the AuthConfig
config = om.AuthConfig('account@oyorooms.com')

# Upload the data to OneDrive Excel
dc = om.DriveClient(config)
df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
drive_item = dc.df_to_xlsx(df, 'folder/test.xlsx')

# Create the Workbook Client using the Drive Item rather than a URL, and add permissions
wc = om.WorkbookClient(config, drive_item=drive_item)
wc.share_with_users(['user@oyorooms.com'])

# Pass the WorkbookClient as an attachment to a Teams message
tc = om.TeamsClient(config)
tc.send_message('PFA your Excel File $TAG(user@oyorooms.com)', 
                channel_url='teams/channel/link',
                attachments=[wc])
```

```r
library(oyoms)
library(tibble)

# Set up the Auth Config
config <- auth_config$new("account@oyorooms.com")

# Upload the data to OneDrive Excel
dc <- drive_client$new(config)
df <- tibble(x = 1:3, y = 4:6)
dc$df_to_xlsx(df, "folder/test.xlsx")

# Create the Workbook Client using the Drive Item rather than a URL, and add permissions
wc <- workbook_client$new(config)
wc$share_with_users(c("user@oyorooms.com"))

# Pass the WorkbookClient as an attachment to a Teams message
tc <- teams_client$new(config)
tc$send_message("PFA your Excel File $TAG(user@oyorooms.com)", 
                channel_url = "teams/channel/link",
                attachments = c(wc))
```

## For Developers

### Custom API Calls
If you need more customized access to the Microsoft Graph API, the Core Client object can provide a simple point
of entry. For example, the following code sends a GET request to the simplest Microsoft Graph API endpoint, `/me`, 
which returns your User data:

```python
from oyoms.core import CoreClient
cc = CoreClient('account@oyorooms.com')
print(cc.get('/me'))
```

```r
library(oyoms)
cc <- core_client$new("account@oyorooms.com")
print(cc$get("/me"))
```

Please note that in general, you will need to pass in a list of `scopes` into the Client object that will apply
to your specific API (see the source code for the Workbook Client as an example). Any additional scopes added
will possibly require an Auth Token refresh, as each Token is limited to the scopes which it was initially granted.

### Contributions
If you would like to develop classes to wrap other Microsoft 365 products or to extend the existing classes, ask to join 
as a code owner by contacting the members of `CODEOWNERS`, after which you can submit and review Pull Requests.

### Deployment - Python

We are currently hosting the Python package on _nexus.oyorooms.io_, available through `pip install` as described
in the [Installation](#installing-the-package) section.

To update the available version of the Python package, you must first make sure that you have updated the package 
version number in the file `/oyoms/python/src/oyoms/__init__.py`. 
Otherwise you risk overwriting an existing version in the repository.

To upload the new version of the Python package, make sure you have `build` and `twine` installed:

```commandline
pip install build twine
```
Next, copy the file `oyoms/python/.pypirc` to your machine at the address `$HOME/.pypirc`. On Mac, this typically looks
like `/Users/stephen/.pypirc`, while on Windows this typically looks like `C:\Users\Stephen\.pypirc`. The file needs
to have the keyword `DEPLOYER_PASSWORD` replaced with the correct password; contact the owners of
this repository or the MLOps team to acquire this password.

Next, you must build the package locally by navigating to `/oyoms/python`, and running
```commandline
python -m build
```
You should see new files created in the `/oyoms/python/dist` folder reflecting your version number.
If you have done this process before, you may need to clear the `dist` folder before the `build` step,
as `twine` will not allow repeat version uploads.
Finally, you can upload the package by running
```commandline
twine upload -r nexus_release dist/*
```
If this is a critical update, be sure to notify the user base to upgrade their copies of `oyoms` by adding the 
upgrade flag `-U` to their `pip install` commands.


### Deployment - R

We are currently hosting the R package on an internal EC2, available through `install.packages` as described
in the [Installation](#installing-the-package) section. However, any internal virtual machine can serve this
purpose, so these instructions are written with a generic server in mind.

To update the available version of the R package, you must first make sure that you have updated the package 
version number in the file `/oyoms/R/DESCRIPTION`. 
Otherwise you risk overwriting an existing version in the repository.

The package building process is performed on the server itself. Git clone this repository onto the server,
and make sure that the `devtools` package is installed:
```R
install.packages("devtools")
```

Next, you build the package by navigating to `/oyoms/R`, and running
```commandline
Rscript repo.R
```
This script will build and load the package to the directory `~/OYOMS_R_REPO`. 
If this is a critical update, be sure to notify the user base to upgrade their copies of `oyoms` by re-running
the `install.packages` command.

Finally, navigate to `~/OYOMS_R_REPO`, and spin up an HTTP server to serve the package:
```commandline
python3 -m http.server 9000
```

Coordinate with DevOps to guarantee that the port (in this case, 9000) is accessible via the VPN.
The current server location is `http://10.50.50.130:9000`; when this gets moved or replaced, please update
the [Installation](#installing-the-package) section of this README to reflect the new address.
In theory, multiple servers can be running across the organization that supply this package.

### Sharing Docs with Non-GitHub Users

Some users of this package will not have GitHub access, and therefore will lack access to this documentation.
To generate an HTML version of this README which can be easily distributed, you can run the following
from the `oyoms` directory:
```commandline
python -m markdown -x extra -x toc -x nl2br README.md > oyoms_readme.html
```

## Issues

View or log issues on the [Issues](https://github.com/oyorooms/oyoms/issues) tab in the repo.
